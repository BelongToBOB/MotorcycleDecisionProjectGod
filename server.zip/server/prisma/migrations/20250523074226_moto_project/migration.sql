-- AlterTable
ALTER TABLE `motorcycle` ADD COLUMN `picture` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `mototype` ADD COLUMN `picture` VARCHAR(191) NULL;
