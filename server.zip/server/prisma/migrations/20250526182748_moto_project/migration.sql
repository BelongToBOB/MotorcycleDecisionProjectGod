-- AlterTable
ALTER TABLE `motorcycle` ADD COLUMN `fuel_size` DOUBLE NULL;
